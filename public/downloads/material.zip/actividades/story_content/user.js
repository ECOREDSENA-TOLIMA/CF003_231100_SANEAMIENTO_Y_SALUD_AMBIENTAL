function ExecuteScript(strId)
{
  switch (strId)
  {
      case "637R5vrTGlf":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

